Name: Prakash Shrestha
blazerid: prakashs

================================
Instruction to use the program
=================================
I have used optimation option while compiling the program. 
Command I have used to compile and run the program are:
1>> gcc -o prakashs_CS730 -O prakashs_CS730.c
2>> ./prakashs_CS730

******   ====  *****   OR *****   =====   *******

I have also created a makefile for you so that it would be easy for you to compile the program.

type 'make' and hit enter it will create object file named "prakashs_CS730". Then you can run the program with 
./prakashs_CS730 
